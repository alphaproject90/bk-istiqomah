<aside class="space-y-6">
  <div class="bg-white p-4 rounded shadow">
    <h4 class="text-lg font-semibold mb-2">Agenda BK</h4>
    <?php dynamic_sidebar('agenda-sidebar'); ?>
  </div>
</aside>
