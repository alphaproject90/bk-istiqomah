  <footer class="bg-blue-700 text-white text-center py-4 mt-10">
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
